﻿#if __IOS__
using System;
using UIKit;

namespace Common.Core
{
    public class Device : IDevice
    {
        public DeviceInfo GetDeviceInformation()
        {
            var di = new DeviceInfo();
            if (ObjCRuntime.Runtime.Arch.ToString() == "SIMULATOR")
            {
                di.DeviceType = DeviceState.Simulator;
            }
            else {
                di.Model = UIDevice.CurrentDevice.Model;
                di.Name = UIDevice.CurrentDevice.Name;
                di.OSVersion = UIDevice.CurrentDevice.SystemName;
                di.DeviceType = DeviceState.PhysicalDevice;
                di.SerialNumber = UIDevice.CurrentDevice.IdentifierForVendor.AsString();
            }

            return di;
        }
    }
}
#endif

